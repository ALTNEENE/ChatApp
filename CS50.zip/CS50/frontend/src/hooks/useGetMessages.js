import React, { useEffect, useState } from 'react'
import useConversation from '../zustand/useConversation'
import {toast} from 'react-hot-toast'
import api from '../api'
import {useAuthContext} from '../context/useAuthContext'
import {jwtDecode} from 'jwt-decode'

const useGetMessages = () => {
    const [loading, setLoading] = useState(false)
    const {users, messages, setMessages} = useConversation()
    const {authUser} = useAuthContext()
    const user = jwtDecode(authUser)
    const reciver_id = users?.id
    
    useEffect(() => {
        const getMessage = async () => {
            setLoading(true)
            try {
                const res = await api.get(`/api/messages/${reciver_id}`)
                const data = res.data
                setMessages(data)
            } catch (error) {
                toast.success("No messages to fetch yet ...")
                setMessages([])
            } finally {
                setLoading(false)
            }
        }
        if (users?.id) getMessage();
    }, [users?.id, setMessages])

    return {messages, loading}
}

export default useGetMessages
