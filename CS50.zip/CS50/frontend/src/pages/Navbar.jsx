import React from 'react'

const Navbar = () => {
  return (
    <div className='navbar bg-sky-500 flex justify-center items-center w-full'>
      <h1>NavBar</h1>
    </div>
  )
}

export default Navbar
